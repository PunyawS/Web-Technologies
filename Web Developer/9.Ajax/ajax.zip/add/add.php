<?php
	$a = $_GET["a"];
	$b = $_GET["b"];
	echo "<b>ผลลัพธ์</b> คือ ";
	echo $a + $b;
?>